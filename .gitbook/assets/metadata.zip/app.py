import os
from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET', 'defaultsecret')
app.config['UPLOAD_FOLDER'] = 'uploads'

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'image' not in request.files:
            flash('No file part', 'danger')
            return redirect(request.url)

        file = request.files['image']
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)

        if file:
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename.replace(' ','').strip())
            file.save(file_path)

            try:
                result = os.popen(f'exiftool {file_path}').read()
                if "Meta" in result:
                    msg = "Hacking Attempt Detected!!"
                    return render_template('index.html', metadata=msg)
                else:    
                    return render_template('index.html', metadata=result)
            except Exception:
                msg = "Hacking Attempt Detected!!"
                return render_template('index.html', metadata=msg) 

    return render_template('index.html', metadata=None)

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(host='0.0.0.0', port=5000, debug=False)
